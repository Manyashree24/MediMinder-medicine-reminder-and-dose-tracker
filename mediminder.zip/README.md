# 💊 MediMinder – Medicine Schedule & Adherence Tracker

A simple web app to plan daily medicines, tick off each dose and track how well you follow the plan.

## Features
- Add medicines with dose, meal timing (before/after food) and multiple daily times
- Today's schedule with "Taken ✓" buttons; overdue doses shown in red
- In-page reminder pop-up when a dose time arrives (while the page is open)
- Stats: doses taken today, 7-day adherence %, and day streak
- Data saved in the browser (localStorage) – no server or login needed

## Tech
HTML, CSS, vanilla JavaScript (single file, no dependencies)

## Run
Open `index.html` in any browser, or host it with GitHub Pages.

> Disclaimer: a reminder tool only. Always follow your doctor's prescription.
